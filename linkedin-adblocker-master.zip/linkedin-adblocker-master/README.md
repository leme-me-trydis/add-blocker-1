### An AdBlocker Extension for LinkedIn in under 100 lines of code!

#### More details: [Build Your Own AdBlocker in (Literally) 10 minutes](https://medium.com/@yakko.majuri/building-your-own-adblocker-in-literally-10-minutes-1eec093b04cd)

